dir = "@DayZ_Epoch";
name = "DayZ Epoch 1.0.6 RC1";
picture = "z\addons\dayz_code\gui\loadingscreen.paa";
actionName = "Website";
action = "http://www.dayzepoch.com";
