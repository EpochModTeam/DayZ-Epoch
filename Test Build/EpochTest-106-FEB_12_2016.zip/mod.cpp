dir = "@DayZ_Epoch";
name = "DayZ Epoch 1.0.6";
actionName = "Website";
picture = "dayz_logo_ca.paa";
action = "http://www.dayzepoch.com";
